---
layout: page
title: À propos
ref: about
lang: fr
---

Ceci est le thème par défaut de Jekyll. Vous pouvez en savoir plus sur les façons de personnaliser votre propre thème, ainsi que la documation de Jekyll sur [jekyllrb.com](http://jekyllrb.com/)

Vous pouvez trouver ce thème multilingue sur :
{% include icon-github.html username="sylvaindurand" %} /
[multilingual-jekyll](https://github.com/sylvaindurand/multilingual-jekyll)

Vous pouvez trouver le code source de ce nouveau thème Jekyll sur :
{% include icon-github.html username="jglovier" %} /
[jekyll-new](https://github.com/jglovier/jekyll-new)

Enfin, le code source de Jekyll est présenté sur
{% include icon-github.html username="jekyll" %} /
[jekyll](https://github.com/jekyll/jekyll)
